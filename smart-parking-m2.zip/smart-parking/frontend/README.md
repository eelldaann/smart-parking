# Frontend

React + TypeScript (Vite) with Leaflet + OpenStreetMap maps.

## Run

Start the backend first (see `backend/README.md`), then:

```bash
cd frontend
npm install
npm run dev
```

Open http://localhost:5173. Requests to `/api` are forwarded to the backend on port 8000.

## Pages

- **Map** — lots with free spaces, lot card with forecast, booking and payment; AI assistant chat in the corner
- **My bookings** — your reservations and their payment status
- **Owner dashboard** — reservations and revenue per lot
- `/payment/success`, `/payment/cancel` — return pages after checkout
- `/mock-pay/:session` — fake checkout page when Stripe is not configured
