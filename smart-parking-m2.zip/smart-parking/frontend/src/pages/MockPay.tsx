import { useEffect, useState } from "react";
import { api, kzt, type Reservation } from "../api";
import { navigate } from "../router";

// Fake checkout page used when Stripe is not configured (PAYMENT_PROVIDER=mock).
export default function MockPay({ sessionId }: { sessionId: string }) {
  const [reservation, setReservation] = useState<Reservation | null>(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    api.confirm(sessionId).then(setReservation).catch((e: Error) => setError(e.message));
  }, [sessionId]);

  async function pay() {
    setBusy(true);
    try {
      await api.completeMock(sessionId);
      navigate(`/payment/success?session_id=${encodeURIComponent(sessionId)}`);
    } catch (e) {
      setError((e as Error).message);
      setBusy(false);
    }
  }

  return (
    <div className="checkout">
      <div className="checkout-card">
        <p className="badge">Test payment</p>
        <h1>Smart Parking</h1>
        {reservation && (
          <>
            <p>
              {reservation.lot_name}
              <br />
              {reservation.date}, {reservation.start_time}–{reservation.end_time}
            </p>
            <p className="checkout-total">{kzt(reservation.amount)}</p>
          </>
        )}
        <label>
          Card number
          <input value="4242 4242 4242 4242" readOnly />
        </label>
        {error && <p className="error">{error}</p>}
        <button className="primary" onClick={pay} disabled={busy || !reservation}>
          {busy ? "Paying…" : "Pay"}
        </button>
        <button className="link" onClick={() => navigate(`/payment/cancel?reservation_id=${reservation?.id ?? ""}`)}>
          Cancel
        </button>
        <p className="muted small-text">Demo mode: no real card is charged.</p>
      </div>
    </div>
  );
}
