import { useEffect, useState } from "react";
import { api, kzt, type Reservation } from "../api";

export default function MyBookings({ userName }: { userName: string }) {
  const [items, setItems] = useState<Reservation[]>([]);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!userName.trim()) return;
    api.myReservations(userName).then(setItems).catch((e: Error) => setError(e.message));
  }, [userName]);

  async function pay(id: number) {
    try {
      const checkout = await api.pay(id);
      window.location.href = checkout.payment_url;
    } catch (e) {
      setError((e as Error).message);
    }
  }

  if (!userName.trim()) return <p className="page">Enter your name in the top bar to see your bookings.</p>;

  return (
    <div className="page">
      <h1>My bookings</h1>
      {error && <p className="error">{error}</p>}
      {items.length === 0 && <p className="muted">No bookings yet.</p>}
      <table className="table">
        <thead>
          <tr>
            <th>Lot</th>
            <th>Date</th>
            <th>Time</th>
            <th>Amount</th>
            <th>Status</th>
            <th />
          </tr>
        </thead>
        <tbody>
          {items.map((r) => (
            <tr key={r.id}>
              <td>{r.lot_name}</td>
              <td>{r.date}</td>
              <td>
                {r.start_time}–{r.end_time}
              </td>
              <td>{kzt(r.amount)}</td>
              <td>
                <span className={`status status-${r.status}`}>{r.status}</span>
              </td>
              <td>{r.status === "pending" && <button className="primary small" onClick={() => pay(r.id)}>Pay</button>}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
