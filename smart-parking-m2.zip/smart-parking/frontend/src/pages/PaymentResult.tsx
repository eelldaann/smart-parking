import { useEffect, useState } from "react";
import { api, kzt, type Reservation } from "../api";
import { navigate } from "../router";

export default function PaymentResult({ kind }: { kind: "success" | "cancel" }) {
  const params = new URLSearchParams(window.location.search);
  const sessionId = params.get("session_id");
  const [reservation, setReservation] = useState<Reservation | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    if (kind !== "success" || !sessionId) return;
    let tries = 0;
    let timer: number | undefined;
    const check = () => {
      api
        .confirm(sessionId)
        .then((r) => {
          setReservation(r);
          // Stripe may need a moment to mark the session as paid.
          if (r.status !== "paid" && tries++ < 5) timer = window.setTimeout(check, 1500);
        })
        .catch((e: Error) => setError(e.message));
    };
    check();
    return () => window.clearTimeout(timer);
  }, [kind, sessionId]);

  return (
    <div className="page narrow">
      {kind === "cancel" ? (
        <>
          <h1>Payment cancelled</h1>
          <p className="muted">Your booking is waiting for payment for 30 minutes. You can pay it in “My bookings”.</p>
        </>
      ) : reservation?.status === "paid" ? (
        <>
          <h1>Booking confirmed</h1>
          <p>
            {reservation.lot_name}, {reservation.date}, {reservation.start_time}–{reservation.end_time}
          </p>
          <p className="muted">Paid {kzt(reservation.amount)}. Show booking #{reservation.id} at the entrance.</p>
        </>
      ) : (
        <>
          <h1>Checking payment…</h1>
          {error && <p className="error">{error}</p>}
        </>
      )}
      <button className="primary" onClick={() => navigate("/my-bookings")}>
        Go to my bookings
      </button>
    </div>
  );
}
