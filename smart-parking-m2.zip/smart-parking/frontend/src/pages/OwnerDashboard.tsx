import { useEffect, useState } from "react";
import { api, kzt, type OwnerRow, type Reservation } from "../api";

const TOKEN_KEY = "sp-owner-token";

function OwnerLogin({ onLogin }: { onLogin: (token: string) => void }) {
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit() {
    setBusy(true);
    setError("");
    try {
      const { token } = await api.ownerLogin(password);
      onLogin(token);
    } catch (e) {
      setError((e as Error).message);
      setBusy(false);
    }
  }

  return (
    <div className="page narrow">
      <h1>Owner login</h1>
      <p className="muted">The owner dashboard shows all bookings and revenue, so it is protected by a password.</p>
      <form
        className="login-form"
        onSubmit={(e) => {
          e.preventDefault();
          submit();
        }}
      >
        <label>
          Password
          <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} autoFocus />
        </label>
        {error && <p className="error">{error}</p>}
        <button className="primary" disabled={busy || !password}>
          {busy ? "Checking…" : "Log in"}
        </button>
      </form>
    </div>
  );
}

export default function OwnerDashboard() {
  const [token, setToken] = useState(() => localStorage.getItem(TOKEN_KEY) ?? "");
  const [rows, setRows] = useState<OwnerRow[]>([]);
  const [reservations, setReservations] = useState<Reservation[]>([]);
  const [error, setError] = useState("");

  function login(newToken: string) {
    localStorage.setItem(TOKEN_KEY, newToken);
    setToken(newToken);
  }

  function logout() {
    localStorage.removeItem(TOKEN_KEY);
    setToken("");
    setRows([]);
    setReservations([]);
  }

  useEffect(() => {
    if (!token) return;
    setError("");
    Promise.all([api.ownerSummary(token), api.ownerReservations(token)])
      .then(([summary, list]) => {
        setRows(summary);
        setReservations(list);
      })
      .catch((e: Error) => {
        if (e.message.includes("login")) logout();
        else setError(e.message);
      });
  }, [token]);

  if (!token) return <OwnerLogin onLogin={login} />;

  const revenue = rows.reduce((sum, r) => sum + r.revenue, 0);
  const paid = rows.reduce((sum, r) => sum + r.paid_count, 0);

  return (
    <div className="page">
      <div className="page-head">
        <h1>Owner dashboard</h1>
        <button className="link" onClick={logout}>
          Log out
        </button>
      </div>
      {error && <p className="error">{error}</p>}
      <div className="stats">
        <div className="stat">
          <span className="stat-value">{kzt(revenue)}</span>
          <span className="muted">Revenue from paid bookings</span>
        </div>
        <div className="stat">
          <span className="stat-value">{paid}</span>
          <span className="muted">Paid bookings</span>
        </div>
        <div className="stat">
          <span className="stat-value">{rows.length}</span>
          <span className="muted">Parking lots</span>
        </div>
      </div>

      <h2 className="section-title">Lots</h2>
      <table className="table">
        <thead>
          <tr>
            <th>Lot</th>
            <th>Spaces (online)</th>
            <th>Price / hour</th>
            <th>Paid</th>
            <th>Waiting for payment</th>
            <th>Revenue</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((r) => (
            <tr key={r.id}>
              <td>{r.name}</td>
              <td>
                {r.total_spaces} ({r.online_spaces})
              </td>
              <td>{kzt(r.price_per_hour)}</td>
              <td>{r.paid_count}</td>
              <td>{r.pending_count}</td>
              <td>{kzt(r.revenue)}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <h2 className="section-title">All bookings</h2>
      {reservations.length === 0 ? (
        <p className="muted">No bookings yet.</p>
      ) : (
        <table className="table">
          <thead>
            <tr>
              <th>#</th>
              <th>Driver</th>
              <th>Lot</th>
              <th>Date</th>
              <th>Time</th>
              <th>Amount</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {reservations.map((r) => (
              <tr key={r.id}>
                <td>{r.id}</td>
                <td>{r.user_name}</td>
                <td>{r.lot_name}</td>
                <td>{r.date}</td>
                <td>
                  {r.start_time}–{r.end_time}
                </td>
                <td>{kzt(r.amount)}</td>
                <td>
                  <span className={`status status-${r.status}`}>{r.status}</span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
