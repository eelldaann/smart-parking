import { useEffect, useState } from "react";
import { api, kzt, type OwnerRow } from "../api";

export default function OwnerDashboard() {
  const [rows, setRows] = useState<OwnerRow[]>([]);
  const [error, setError] = useState("");

  useEffect(() => {
    api.ownerSummary().then(setRows).catch((e: Error) => setError(e.message));
  }, []);

  const revenue = rows.reduce((sum, r) => sum + r.revenue, 0);
  const paid = rows.reduce((sum, r) => sum + r.paid_count, 0);

  return (
    <div className="page">
      <h1>Owner dashboard</h1>
      {error && <p className="error">{error}</p>}
      <div className="stats">
        <div className="stat">
          <span className="stat-value">{kzt(revenue)}</span>
          <span className="muted">Revenue from paid bookings</span>
        </div>
        <div className="stat">
          <span className="stat-value">{paid}</span>
          <span className="muted">Paid bookings</span>
        </div>
        <div className="stat">
          <span className="stat-value">{rows.length}</span>
          <span className="muted">Parking lots</span>
        </div>
      </div>
      <table className="table">
        <thead>
          <tr>
            <th>Lot</th>
            <th>Spaces (online)</th>
            <th>Price / hour</th>
            <th>Paid</th>
            <th>Waiting for payment</th>
            <th>Revenue</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((r) => (
            <tr key={r.id}>
              <td>{r.name}</td>
              <td>
                {r.total_spaces} ({r.online_spaces})
              </td>
              <td>{kzt(r.price_per_hour)}</td>
              <td>{r.paid_count}</td>
              <td>{r.pending_count}</td>
              <td>{kzt(r.revenue)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
