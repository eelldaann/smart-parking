import { useCallback, useEffect, useState } from "react";
import { api, kzt, type Lot } from "../api";
import MapView from "../components/MapView";
import LotPanel from "../components/LotPanel";
import ChatWidget from "../components/ChatWidget";

export default function MapPage({ userName }: { userName: string }) {
  const [lots, setLots] = useState<Lot[]>([]);
  const [selected, setSelected] = useState<Lot | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    api.lots().then(setLots).catch((e: Error) => setError(e.message));
  }, []);

  const select = useCallback((lot: Lot) => setSelected(lot), []);

  return (
    <div className="map-page">
      <div className="map-area">
        <MapView lots={lots} selectedId={selected?.id ?? null} onSelect={select} />
        <ChatWidget userName={userName} onShowLot={select} />
      </div>
      {selected ? (
        <LotPanel key={selected.id} lot={selected} userName={userName} />
      ) : (
        <aside className="lot-panel">
          <h2>Parking near you</h2>
          {error && <p className="error">Cannot load lots: {error}. Is the backend running?</p>}
          <ul className="lot-list">
            {lots.map((lot) => (
              <li key={lot.id}>
                <button className="lot-row" onClick={() => select(lot)}>
                  <strong>{lot.name}</strong>
                  <span className="muted">
                    {lot.free_now > 0 ? `${lot.free_now} free` : "Full"} · {kzt(lot.price_per_hour)}/h
                  </span>
                </button>
              </li>
            ))}
          </ul>
        </aside>
      )}
    </div>
  );
}
