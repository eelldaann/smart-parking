// Typed helpers for the FastAPI backend (proxied at /api by Vite).

export interface Lot {
  id: number;
  name: string;
  address: string;
  lat: number;
  lng: number;
  kind: string;
  total_spaces: number;
  online_spaces: number;
  price_per_hour: number;
  opens: string;
  closes: string;
  free_now: number;
  occupancy_now: number;
}

export interface Forecast {
  lot_id: number;
  date: string;
  model: string;
  hours: { hour: number; occupancy: number }[];
}

export interface Availability {
  bookable_spaces: number;
  price: number;
}

export interface Reservation {
  id: number;
  lot_id: number;
  lot_name: string;
  lot_address: string;
  user_name: string;
  date: string;
  start_time: string;
  end_time: string;
  amount: number;
  status: "pending" | "paid" | "cancelled";
}

export interface Checkout {
  session_id: string;
  payment_url: string;
  provider: string;
}

export interface ChatMessage {
  role: "user" | "assistant";
  content: string;
}

export type AgentAction =
  | { type: "lots"; lots: Lot[] }
  | { type: "payment"; reservation: Reservation; payment_url: string };

export interface AgentReply {
  reply: string;
  actions: AgentAction[];
  mode: "llm" | "offline";
}

export interface OwnerRow {
  id: number;
  name: string;
  total_spaces: number;
  online_spaces: number;
  price_per_hour: number;
  paid_count: number;
  pending_count: number;
  revenue: number;
}

async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
  const res = await fetch(`/api${path}`, {
    ...options,
    headers: { "Content-Type": "application/json", ...(options.headers ?? {}) },
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const detail = typeof data.detail === "string" ? data.detail : "Something went wrong";
    throw new Error(detail);
  }
  return data as T;
}

const q = (params: Record<string, string>) => new URLSearchParams(params).toString();

export const api = {
  lots: () => request<Lot[]>("/lots"),
  forecast: (lotId: number, date: string) => request<Forecast>(`/lots/${lotId}/forecast?${q({ date })}`),
  availability: (lotId: number, date: string, start: string, end: string) =>
    request<Availability>(`/lots/${lotId}/availability?${q({ date, start_time: start, end_time: end })}`),
  reserve: (body: { lot_id: number; user_name: string; date: string; start_time: string; end_time: string }) =>
    request<Reservation>("/reservations", { method: "POST", body: JSON.stringify(body) }),
  myReservations: (userName: string) => request<Reservation[]>(`/reservations?${q({ user_name: userName })}`),
  pay: (reservationId: number) => request<Checkout>(`/reservations/${reservationId}/pay`, { method: "POST" }),
  confirm: (sessionId: string) => request<Reservation>(`/payments/confirm?${q({ session_id: sessionId })}`),
  completeMock: (sessionId: string) =>
    request<Reservation>(`/payments/mock/${encodeURIComponent(sessionId)}/complete`, { method: "POST" }),
  chat: (messages: ChatMessage[], userName: string) =>
    request<AgentReply>("/agent/chat", { method: "POST", body: JSON.stringify({ messages, user_name: userName }) }),
  ownerLogin: (password: string) =>
    request<{ token: string }>("/owner/login", { method: "POST", body: JSON.stringify({ password }) }),
  ownerSummary: (token: string) =>
    request<OwnerRow[]>("/owner/summary", { headers: { Authorization: `Bearer ${token}` } }),
  ownerReservations: (token: string) =>
    request<Reservation[]>("/owner/reservations", { headers: { Authorization: `Bearer ${token}` } }),
};

export function tomorrowISO(): string {
  const d = new Date();
  d.setDate(d.getDate() + 1);
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

export const kzt = (n: number) => `${n.toLocaleString("ru-RU")} ₸`;
