import { useRef, useState } from "react";
import { api, kzt, type AgentAction, type ChatMessage, type Lot } from "../api";

interface Props {
  userName: string;
  onShowLot: (lot: Lot) => void;
}

interface Entry extends ChatMessage {
  actions?: AgentAction[];
}

const HELLO: Entry = {
  role: "assistant",
  content: "Hi! Tell me where and when you need parking, e.g. “Central Mall tomorrow 14:00–16:00 under 500 KZT”.",
};

export default function ChatWidget({ userName, onShowLot }: Props) {
  const [open, setOpen] = useState(false);
  const [entries, setEntries] = useState<Entry[]>([HELLO]);
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const bottom = useRef<HTMLDivElement>(null);

  async function send() {
    const content = text.trim();
    if (!content || busy) return;
    const next: Entry[] = [...entries, { role: "user", content }];
    setEntries(next);
    setText("");
    setBusy(true);
    try {
      const history: ChatMessage[] = next.slice(1).map(({ role, content }) => ({ role, content }));
      const res = await api.chat(history, userName || "Guest");
      setEntries([...next, { role: "assistant", content: res.reply, actions: res.actions }]);
    } catch (e) {
      setEntries([...next, { role: "assistant", content: `Error: ${(e as Error).message}` }]);
    } finally {
      setBusy(false);
      setTimeout(() => bottom.current?.scrollIntoView({ behavior: "smooth" }), 50);
    }
  }

  if (!open) {
    return (
      <button className="chat-toggle" onClick={() => setOpen(true)}>
        Ask the assistant
      </button>
    );
  }

  return (
    <section className="chat" aria-label="AI parking assistant">
      <header className="chat-head">
        <strong>AI assistant</strong>
        <button className="link" onClick={() => setOpen(false)} aria-label="Close chat">
          ✕
        </button>
      </header>
      <div className="chat-body">
        {entries.map((entry, i) => (
          <div key={i} className={`msg msg-${entry.role}`}>
            <p>{entry.content}</p>
            {entry.actions?.map((action, j) =>
              action.type === "lots" ? (
                <div key={j} className="chips">
                  {action.lots.map((lot) => (
                    <button key={lot.id} className="chip" onClick={() => onShowLot(lot)}>
                      {lot.name} · {kzt(lot.price_per_hour)}/h
                    </button>
                  ))}
                </div>
              ) : (
                <a key={j} className="primary pay-link" href={action.payment_url}>
                  Pay {kzt(action.reservation.amount)} for {action.reservation.lot_name}
                </a>
              ),
            )}
          </div>
        ))}
        {busy && <div className="msg msg-assistant"><p>Thinking…</p></div>}
        <div ref={bottom} />
      </div>
      <form
        className="chat-input"
        onSubmit={(e) => {
          e.preventDefault();
          send();
        }}
      >
        <input value={text} onChange={(e) => setText(e.target.value)} placeholder="Where and when?" />
        <button className="primary" disabled={busy}>
          Send
        </button>
      </form>
    </section>
  );
}
