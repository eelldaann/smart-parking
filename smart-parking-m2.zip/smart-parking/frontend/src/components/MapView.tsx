import { useEffect, useRef } from "react";
import L from "leaflet";
import type { Lot } from "../api";

interface Props {
  lots: Lot[];
  selectedId: number | null;
  onSelect: (lot: Lot) => void;
}

// Pin with a "P" and the number of free spaces; drawn with HTML so no image assets are needed.
function pinIcon(lot: Lot, selected: boolean) {
  const state = lot.free_now === 0 ? "full" : selected ? "selected" : "normal";
  const label = lot.free_now === 0 ? "Full" : `${lot.free_now} free`;
  return L.divIcon({
    className: "pin-wrap",
    html: `<div class="pin pin-${state}"><span class="pin-p">P</span><span class="pin-label">${label}</span></div>`,
    iconSize: [96, 40],
    iconAnchor: [20, 20],
  });
}

export default function MapView({ lots, selectedId, onSelect }: Props) {
  const box = useRef<HTMLDivElement>(null);
  const map = useRef<L.Map | null>(null);
  const layer = useRef<L.LayerGroup | null>(null);

  useEffect(() => {
    if (!box.current || map.current) return;
    map.current = L.map(box.current).setView([43.232, 76.925], 13);
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      attribution: "&copy; OpenStreetMap contributors",
      maxZoom: 19,
    }).addTo(map.current);
    layer.current = L.layerGroup().addTo(map.current);
    return () => {
      map.current?.remove();
      map.current = null;
    };
  }, []);

  useEffect(() => {
    const group = layer.current;
    if (!group) return;
    group.clearLayers();
    lots.forEach((lot) => {
      L.marker([lot.lat, lot.lng], { icon: pinIcon(lot, lot.id === selectedId), title: lot.name })
        .on("click", () => onSelect(lot))
        .addTo(group);
    });
  }, [lots, selectedId, onSelect]);

  useEffect(() => {
    const lot = lots.find((l) => l.id === selectedId);
    if (lot && map.current) map.current.panTo([lot.lat, lot.lng]);
  }, [selectedId, lots]);

  return <div ref={box} className="map" />;
}
