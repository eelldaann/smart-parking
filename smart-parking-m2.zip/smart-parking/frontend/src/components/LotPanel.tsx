import { useEffect, useState } from "react";
import { api, kzt, tomorrowISO, type Availability, type Forecast, type Lot } from "../api";

interface Props {
  lot: Lot;
  userName: string;
}

export default function LotPanel({ lot, userName }: Props) {
  const [date, setDate] = useState(tomorrowISO());
  const [start, setStart] = useState("14:00");
  const [end, setEnd] = useState("16:00");
  const [forecast, setForecast] = useState<Forecast | null>(null);
  const [slot, setSlot] = useState<Availability | null>(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    api.forecast(lot.id, date).then(setForecast).catch(() => setForecast(null));
  }, [lot.id, date]);

  useEffect(() => {
    setError("");
    setSlot(null);
    if (!date || !start || !end) return;
    api.availability(lot.id, date, start, end).then(setSlot).catch((e: Error) => setError(e.message));
  }, [lot.id, date, start, end]);

  const startHour = Number(start.slice(0, 2));
  const peak = forecast?.hours.find((h) => h.hour === startHour)?.occupancy;

  async function bookAndPay() {
    if (!userName.trim()) {
      setError("Enter your name in the top bar first");
      return;
    }
    setBusy(true);
    setError("");
    try {
      const reservation = await api.reserve({ lot_id: lot.id, user_name: userName, date, start_time: start, end_time: end });
      const checkout = await api.pay(reservation.id);
      window.location.href = checkout.payment_url;
    } catch (e) {
      setError((e as Error).message);
      setBusy(false);
    }
  }

  return (
    <aside className="lot-panel">
      <h2>{lot.name}</h2>
      <p className="muted">{lot.address}</p>
      <p className={lot.free_now > 0 ? "free" : "full"}>
        {lot.free_now > 0 ? `${lot.free_now} of ${lot.total_spaces} spaces free now` : "Full right now"}
      </p>
      <p className="muted">
        {kzt(lot.price_per_hour)} per hour · {lot.opens}–{lot.closes}
      </p>

      <h3>Forecast for {date}</h3>
      <div className="forecast" aria-label="Occupancy forecast by hour">
        {forecast?.hours.map((h) => (
          <div key={h.hour} className="bar-col" title={`${h.hour}:00 — ${Math.round(h.occupancy * 100)}% busy`}>
            <div
              className={h.occupancy >= 0.8 ? "bar bar-high" : "bar"}
              style={{ height: `${Math.max(h.occupancy * 100, 4)}%` }}
            />
            <span className="bar-hour">{h.hour}</span>
          </div>
        ))}
      </div>
      {peak !== undefined && (
        <p className={peak >= 0.8 ? "warn" : "muted"}>
          Expected at {start}: {Math.round(peak * 100)}% busy{peak >= 0.8 ? " — book ahead" : ""}
        </p>
      )}

      <h3>Book a space</h3>
      <div className="form-row">
        <label>
          Date
          <input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
        </label>
      </div>
      <div className="form-row">
        <label>
          From
          <input type="time" step={1800} value={start} onChange={(e) => setStart(e.target.value)} />
        </label>
        <label>
          To
          <input type="time" step={1800} value={end} onChange={(e) => setEnd(e.target.value)} />
        </label>
      </div>
      {slot && (
        <p className="muted">
          {slot.bookable_spaces} spaces can be booked · total {kzt(slot.price)}
        </p>
      )}
      {error && <p className="error">{error}</p>}
      <button className="primary" disabled={busy || !slot || slot.bookable_spaces === 0} onClick={bookAndPay}>
        {busy ? "Opening payment…" : slot ? `Book and pay ${kzt(slot.price)}` : "Book and pay"}
      </button>
    </aside>
  );
}
