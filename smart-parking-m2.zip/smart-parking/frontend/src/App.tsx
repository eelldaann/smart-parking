import { useEffect, useState } from "react";
import MapPage from "./pages/MapPage";
import MyBookings from "./pages/MyBookings";
import OwnerDashboard from "./pages/OwnerDashboard";
import PaymentResult from "./pages/PaymentResult";
import MockPay from "./pages/MockPay";
import { navigate } from "./router";

function usePath() {
  const [path, setPath] = useState(window.location.pathname);
  useEffect(() => {
    const onChange = () => setPath(window.location.pathname);
    window.addEventListener("popstate", onChange);
    return () => window.removeEventListener("popstate", onChange);
  }, []);
  return path;
}

function useUserName(): [string, (name: string) => void] {
  const [name, setName] = useState(() => localStorage.getItem("sp-user") ?? "");
  const save = (value: string) => {
    setName(value);
    localStorage.setItem("sp-user", value);
  };
  return [name, save];
}

export default function App() {
  const path = usePath();
  const [userName, setUserName] = useUserName();

  if (path.startsWith("/mock-pay/")) {
    return <MockPay sessionId={decodeURIComponent(path.slice("/mock-pay/".length))} />;
  }

  let page;
  if (path === "/my-bookings") page = <MyBookings userName={userName} />;
  else if (path === "/owner") page = <OwnerDashboard />;
  else if (path === "/payment/success") page = <PaymentResult kind="success" />;
  else if (path === "/payment/cancel") page = <PaymentResult kind="cancel" />;
  else page = <MapPage userName={userName} />;

  const link = (to: string, label: string) => (
    <a
      href={to}
      className={path === to ? "nav-link active" : "nav-link"}
      onClick={(e) => {
        e.preventDefault();
        navigate(to);
      }}
    >
      {label}
    </a>
  );

  return (
    <div className="app">
      <header className="topbar">
        <div className="brand">
          <span className="brand-mark">P</span>
          <span>Smart Parking</span>
        </div>
        <nav>
          {link("/", "Map")}
          {link("/my-bookings", "My bookings")}
          {link("/owner", "Owner dashboard")}
        </nav>
        <input
          className="name-input"
          placeholder="Your name"
          value={userName}
          onChange={(e) => setUserName(e.target.value)}
          aria-label="Your name"
        />
      </header>
      <main className="content">{page}</main>
    </div>
  );
}
