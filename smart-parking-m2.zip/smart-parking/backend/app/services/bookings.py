"""Reservations: create, list, pay status, owner summary."""
import sqlite3

from .. import config
from . import ServiceError
from .lots import availability, parse_date, parse_time


def _to_dict(row: sqlite3.Row) -> dict:
    return {key: row[key] for key in row.keys()}


def create(conn: sqlite3.Connection, lot_id: int, user_name: str, day: str, start_time: str, end_time: str) -> dict:
    user_name = (user_name or "").strip()
    if not user_name:
        raise ServiceError("Please enter your name")
    now = config.now()
    d = parse_date(day)
    if d < now.date() or (d == now.date() and parse_time(start_time) < now.hour * 60 + now.minute):
        raise ServiceError("This time slot is already in the past")

    slot = availability(conn, lot_id, day, start_time, end_time)
    if slot["bookable_spaces"] <= 0:
        raise ServiceError("No free spaces for this time slot", 409)

    cur = conn.execute(
        "INSERT INTO reservations (lot_id, user_name, date, start_time, end_time, amount, status, created_at)"
        " VALUES (?, ?, ?, ?, ?, ?, 'pending', ?)",
        (lot_id, user_name, day, start_time, end_time, slot["price"],
         now.replace(tzinfo=None).isoformat(timespec="seconds")),
    )
    return get(conn, cur.lastrowid)


def get(conn: sqlite3.Connection, reservation_id: int) -> dict:
    row = conn.execute(
        "SELECT r.*, l.name AS lot_name, l.address AS lot_address FROM reservations r"
        " JOIN lots l ON l.id = r.lot_id WHERE r.id = ?",
        (reservation_id,),
    ).fetchone()
    if row is None:
        raise ServiceError(f"Reservation {reservation_id} not found", 404)
    return _to_dict(row)


def list_for_user(conn: sqlite3.Connection, user_name: str) -> list[dict]:
    rows = conn.execute(
        "SELECT r.*, l.name AS lot_name, l.address AS lot_address FROM reservations r"
        " JOIN lots l ON l.id = r.lot_id WHERE r.user_name = ? ORDER BY r.date DESC, r.start_time DESC",
        (user_name.strip(),),
    ).fetchall()
    return [_to_dict(r) for r in rows]


def set_payment_session(conn: sqlite3.Connection, reservation_id: int, session_id: str) -> None:
    conn.execute("UPDATE reservations SET payment_session = ? WHERE id = ?", (session_id, reservation_id))


def find_by_session(conn: sqlite3.Connection, session_id: str) -> dict:
    row = conn.execute("SELECT id FROM reservations WHERE payment_session = ?", (session_id,)).fetchone()
    if row is None:
        raise ServiceError("Payment session not found", 404)
    return get(conn, row["id"])


def mark_paid(conn: sqlite3.Connection, reservation_id: int) -> dict:
    reservation = get(conn, reservation_id)
    if reservation["status"] == "cancelled":
        raise ServiceError("This reservation was cancelled", 409)
    conn.execute("UPDATE reservations SET status = 'paid' WHERE id = ?", (reservation_id,))
    return get(conn, reservation_id)


def cancel(conn: sqlite3.Connection, reservation_id: int) -> dict:
    reservation = get(conn, reservation_id)
    if reservation["status"] == "paid":
        raise ServiceError("A paid reservation cannot be cancelled here", 409)
    conn.execute("UPDATE reservations SET status = 'cancelled' WHERE id = ?", (reservation_id,))
    return get(conn, reservation_id)


def owner_summary(conn: sqlite3.Connection) -> list[dict]:
    """Reservations and revenue per lot (all lots belong to the demo owner for now)."""
    rows = conn.execute(
        "SELECT l.id, l.name, l.total_spaces, l.online_spaces, l.price_per_hour,"
        " SUM(CASE WHEN r.status = 'paid' THEN 1 ELSE 0 END) AS paid_count,"
        " SUM(CASE WHEN r.status = 'pending' THEN 1 ELSE 0 END) AS pending_count,"
        " COALESCE(SUM(CASE WHEN r.status = 'paid' THEN r.amount END), 0) AS revenue"
        " FROM lots l LEFT JOIN reservations r ON r.lot_id = l.id GROUP BY l.id ORDER BY revenue DESC, l.id"
    ).fetchall()
    return [_to_dict(r) for r in rows]

