"""Simple password protection for the owner dashboard.

The owner logs in with OWNER_PASSWORD and gets a token derived from it.
Changing the password makes old tokens invalid. Full user accounts with
roles come in Milestone 3.
"""
import hashlib
import hmac

from .. import config
from . import ServiceError

_SALT = b"smart-parking-owner-v1"


def _token_for(password: str) -> str:
    return hmac.new(password.encode(), _SALT, hashlib.sha256).hexdigest()


def login(password: str) -> dict:
    if not hmac.compare_digest(password or "", config.owner_password()):
        raise ServiceError("Wrong password", 401)
    return {"token": _token_for(config.owner_password())}


def check(authorization: str) -> None:
    """Raise 401 unless the header is 'Bearer <valid token>'."""
    scheme, _, token = (authorization or "").partition(" ")
    expected = _token_for(config.owner_password())
    if scheme.lower() != "bearer" or not hmac.compare_digest(token.strip(), expected):
        raise ServiceError("Owner login required", 401)
