"""Payment providers behind one interface.

- StripeProvider: Stripe Checkout in test mode (no real money), called over HTTPS.
- MockProvider: a local fake checkout page, used when Stripe is not available
  (plan B from the Milestone 1 risk list).
"""
import base64
import hashlib
import hmac
import json
import secrets
import sqlite3
import time
import urllib.error
import urllib.parse
import urllib.request

from .. import config
from . import ServiceError, bookings

STRIPE_API = "https://api.stripe.com/v1"


class PaymentProvider:
    name = "base"

    def create_checkout(self, reservation: dict) -> dict:
        """Return {"session_id": ..., "payment_url": ...}."""
        raise NotImplementedError

    def is_paid(self, session_id: str) -> bool:
        raise NotImplementedError


class MockProvider(PaymentProvider):
    name = "mock"

    def create_checkout(self, reservation: dict) -> dict:
        session_id = "mock_" + secrets.token_hex(8)
        return {"session_id": session_id, "payment_url": f"{config.frontend_url()}/mock-pay/{session_id}"}

    def is_paid(self, session_id: str) -> bool:
        return False  # mock payments are completed through complete_mock()


class StripeProvider(PaymentProvider):
    name = "stripe"

    def __init__(self, secret_key: str, currency: str = "kzt"):
        if not secret_key:
            raise ServiceError("STRIPE_SECRET_KEY is not set", 500)
        self.secret_key = secret_key
        self.currency = currency.lower()

    def _request(self, method: str, path: str, data: dict | None = None) -> dict:
        body = urllib.parse.urlencode(data).encode() if data else None
        req = urllib.request.Request(f"{STRIPE_API}{path}", data=body, method=method)
        token = base64.b64encode(f"{self.secret_key}:".encode()).decode()
        req.add_header("Authorization", f"Basic {token}")
        try:
            with urllib.request.urlopen(req, timeout=20) as resp:
                return json.loads(resp.read())
        except urllib.error.HTTPError as err:
            detail = json.loads(err.read() or b"{}").get("error", {}).get("message", str(err))
            raise ServiceError(f"Stripe error: {detail}", 502)
        except urllib.error.URLError as err:
            raise ServiceError(f"Cannot reach Stripe: {err.reason}", 502)

    def create_checkout(self, reservation: dict) -> dict:
        front = config.frontend_url()
        session = self._request("POST", "/checkout/sessions", {
            "mode": "payment",
            "line_items[0][quantity]": "1",
            "line_items[0][price_data][currency]": self.currency,
            # KZT is a two-decimal currency in Stripe: amounts are sent in tiyn.
            "line_items[0][price_data][unit_amount]": str(reservation["amount"] * 100),
            "line_items[0][price_data][product_data][name]":
                f"Parking: {reservation['lot_name']}, {reservation['date']} "
                f"{reservation['start_time']}–{reservation['end_time']}",
            "client_reference_id": str(reservation["id"]),
            "metadata[reservation_id]": str(reservation["id"]),
            "success_url": f"{front}/payment/success?session_id={{CHECKOUT_SESSION_ID}}",
            "cancel_url": f"{front}/payment/cancel?reservation_id={reservation['id']}",
        })
        return {"session_id": session["id"], "payment_url": session["url"]}

    def is_paid(self, session_id: str) -> bool:
        session = self._request("GET", f"/checkout/sessions/{urllib.parse.quote(session_id)}")
        return session.get("payment_status") == "paid"


def get_provider() -> PaymentProvider:
    if config.payment_provider_name() == "stripe":
        return StripeProvider(config.env("STRIPE_SECRET_KEY"), config.env("STRIPE_CURRENCY", "kzt"))
    return MockProvider()


def start_checkout(conn: sqlite3.Connection, reservation_id: int, provider: PaymentProvider | None = None) -> dict:
    provider = provider or get_provider()
    reservation = bookings.get(conn, reservation_id)
    if reservation["status"] == "paid":
        raise ServiceError("This reservation is already paid", 409)
    if reservation["status"] == "cancelled":
        raise ServiceError("This reservation was cancelled", 409)
    checkout = provider.create_checkout(reservation)
    bookings.set_payment_session(conn, reservation_id, checkout["session_id"])
    return {**checkout, "provider": provider.name, "reservation_id": reservation_id}


def confirm(conn: sqlite3.Connection, session_id: str, provider: PaymentProvider | None = None) -> dict:
    """Check a session after the redirect back from checkout (works without webhooks)."""
    reservation = bookings.find_by_session(conn, session_id)
    if reservation["status"] != "paid":
        provider = provider or get_provider()
        if not session_id.startswith("mock_") and provider.is_paid(session_id):
            reservation = bookings.mark_paid(conn, reservation["id"])
    return reservation


def complete_mock(conn: sqlite3.Connection, session_id: str) -> dict:
    if not session_id.startswith("mock_"):
        raise ServiceError("Not a mock payment session", 400)
    reservation = bookings.find_by_session(conn, session_id)
    return bookings.mark_paid(conn, reservation["id"])


def verify_stripe_signature(payload: bytes, header: str, secret: str, tolerance: int = 300) -> dict:
    """Check the Stripe-Signature header and return the parsed event."""
    if not secret:
        raise ServiceError("STRIPE_WEBHOOK_SECRET is not set", 500)
    parts = {}
    for item in (header or "").split(","):
        key, _, value = item.partition("=")
        parts.setdefault(key.strip(), []).append(value.strip())
    try:
        timestamp = int(parts["t"][0])
    except (KeyError, ValueError):
        raise ServiceError("Invalid Stripe signature header", 400)
    if abs(time.time() - timestamp) > tolerance:
        raise ServiceError("Stripe signature is too old", 400)
    expected = hmac.new(secret.encode(), f"{timestamp}.".encode() + payload, hashlib.sha256).hexdigest()
    if not any(hmac.compare_digest(expected, sig) for sig in parts.get("v1", [])):
        raise ServiceError("Invalid Stripe signature", 400)
    return json.loads(payload)


def handle_webhook(conn: sqlite3.Connection, payload: bytes, signature: str) -> dict:
    event = verify_stripe_signature(payload, signature, config.env("STRIPE_WEBHOOK_SECRET"))
    if event.get("type") == "checkout.session.completed":
        session = event["data"]["object"]
        reservation_id = int(session.get("metadata", {}).get("reservation_id") or session["client_reference_id"])
        if session.get("payment_status") == "paid":
            bookings.mark_paid(conn, reservation_id)
    return {"received": True}
