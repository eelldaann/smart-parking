class ServiceError(Exception):
    """An error the API turns into a 4xx response."""

    def __init__(self, message: str, status: int = 400):
        super().__init__(message)
        self.message = message
        self.status = status
