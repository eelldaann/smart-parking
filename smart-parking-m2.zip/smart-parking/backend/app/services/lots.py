"""Parking lots: search, occupancy forecast and availability.

The forecast here is a rule-based baseline (typical hourly profiles per lot type).
In Milestone 3 it is replaced by the trained ML model from ml/.
"""
import math
import sqlite3
from datetime import date as Date, datetime, timedelta

from .. import config
from . import ServiceError

# Typical share of occupied spaces by hour (0-23) for each kind of lot.
_PROFILES = {
    "mall": [0.05] * 8 + [0.15, 0.25, 0.35, 0.5, 0.6, 0.65, 0.65, 0.6, 0.6, 0.7, 0.85, 0.9, 0.8, 0.6, 0.35, 0.15],
    "business": [0.05] * 7 + [0.3, 0.7, 0.9, 0.95, 0.95, 0.85, 0.9, 0.9, 0.85, 0.75, 0.5, 0.3, 0.15, 0.1, 0.05, 0.05, 0.05],
    "residential": [0.9] * 7 + [0.75, 0.55, 0.45, 0.4, 0.4, 0.4, 0.4, 0.4, 0.45, 0.5, 0.6, 0.7, 0.8, 0.85, 0.9, 0.9, 0.9],
}
_WEEKEND_FACTOR = {"mall": 1.15, "business": 0.35, "residential": 1.05}
_PENDING_TTL = timedelta(minutes=30)  # unpaid bookings hold a space this long


def parse_date(value: str) -> Date:
    try:
        return Date.fromisoformat(value)
    except (TypeError, ValueError):
        raise ServiceError(f"Invalid date '{value}', expected YYYY-MM-DD")


def parse_time(value: str) -> int:
    """Return minutes since midnight for an HH:MM string."""
    try:
        hours, minutes = value.split(":")
        h, m = int(hours), int(minutes)
    except (AttributeError, ValueError):
        raise ServiceError(f"Invalid time '{value}', expected HH:MM")
    if not (0 <= h <= 24 and 0 <= m < 60) or h * 60 + m > 24 * 60:
        raise ServiceError(f"Invalid time '{value}', expected HH:MM")
    return h * 60 + m


def occupancy(kind: str, day: Date, hour: int) -> float:
    """Forecast share of occupied spaces (0..1) for a lot kind at a given hour."""
    base = _PROFILES.get(kind, _PROFILES["mall"])[hour % 24]
    if day.weekday() >= 5:
        base *= _WEEKEND_FACTOR.get(kind, 1.0)
    return round(min(base, 0.98), 2)


def forecast(conn: sqlite3.Connection, lot_id: int, day: str) -> dict:
    lot = get_lot_row(conn, lot_id)
    d = parse_date(day)
    opens, closes = parse_time(lot["opens"]), parse_time(lot["closes"])
    hours = [
        {"hour": h, "occupancy": occupancy(lot["kind"], d, h)}
        for h in range(24)
        if opens // 60 <= h <= (closes - 1) // 60
    ]
    return {"lot_id": lot_id, "date": day, "model": "baseline-v1", "hours": hours}


def get_lot_row(conn: sqlite3.Connection, lot_id: int) -> sqlite3.Row:
    row = conn.execute("SELECT * FROM lots WHERE id = ?", (lot_id,)).fetchone()
    if row is None:
        raise ServiceError(f"Parking lot {lot_id} not found", 404)
    return row


def free_now(lot: sqlite3.Row, at: datetime | None = None) -> int:
    at = at or config.now()
    minutes = at.hour * 60 + at.minute
    if not (parse_time(lot["opens"]) <= minutes < parse_time(lot["closes"])):
        return 0
    taken = math.ceil(lot["total_spaces"] * occupancy(lot["kind"], at.date(), at.hour))
    return max(lot["total_spaces"] - taken, 0)


def lot_to_dict(lot: sqlite3.Row, at: datetime | None = None) -> dict:
    at = at or config.now()
    return {
        "id": lot["id"],
        "name": lot["name"],
        "address": lot["address"],
        "lat": lot["lat"],
        "lng": lot["lng"],
        "kind": lot["kind"],
        "total_spaces": lot["total_spaces"],
        "online_spaces": lot["online_spaces"],
        "price_per_hour": lot["price_per_hour"],
        "opens": lot["opens"],
        "closes": lot["closes"],
        "free_now": free_now(lot, at),
        "occupancy_now": occupancy(lot["kind"], at.date(), at.hour),
    }


def get_lot(conn: sqlite3.Connection, lot_id: int) -> dict:
    return lot_to_dict(get_lot_row(conn, lot_id))


def search(conn: sqlite3.Connection, query: str = "", max_price: int | None = None) -> list[dict]:
    rows = conn.execute("SELECT * FROM lots ORDER BY price_per_hour").fetchall()
    words = [w for w in query.lower().split() if len(w) > 2]
    scored = []
    for row in rows:
        text = f"{row['name']} {row['address']} {row['kind']}".lower()
        score = sum(1 for w in words if w in text)
        if words and score == 0:
            continue
        if max_price is not None and row["price_per_hour"] > max_price:
            continue
        scored.append((score, row))
    # best text match first, then cheapest (rows are already sorted by price)
    scored.sort(key=lambda item: -item[0])
    return [lot_to_dict(row) for _, row in scored]


def overlapping_count(conn: sqlite3.Connection, lot_id: int, day: str, start: int, end: int) -> int:
    """Active reservations (paid, or pending for less than 30 minutes) that overlap a slot."""
    cutoff = (config.now().replace(tzinfo=None) - _PENDING_TTL).isoformat(timespec="seconds")
    rows = conn.execute(
        "SELECT start_time, end_time FROM reservations WHERE lot_id = ? AND date = ?"
        " AND (status = 'paid' OR (status = 'pending' AND created_at >= ?))",
        (lot_id, day, cutoff),
    ).fetchall()
    return sum(1 for r in rows if start < parse_time(r["end_time"]) and end > parse_time(r["start_time"]))


def availability(conn: sqlite3.Connection, lot_id: int, day: str, start_time: str, end_time: str) -> dict:
    lot = get_lot_row(conn, lot_id)
    parse_date(day)
    start, end = parse_time(start_time), parse_time(end_time)
    if end <= start:
        raise ServiceError("End time must be after start time")
    if start < parse_time(lot["opens"]) or end > parse_time(lot["closes"]):
        raise ServiceError(f"The lot is open {lot['opens']}–{lot['closes']}")
    booked = overlapping_count(conn, lot_id, day, start, end)
    return {
        "lot_id": lot_id,
        "date": day,
        "start_time": start_time,
        "end_time": end_time,
        "bookable_spaces": max(lot["online_spaces"] - booked, 0),
        "price": price_for(lot["price_per_hour"], start, end),
    }


def price_for(price_per_hour: int, start: int, end: int) -> int:
    """Price in KZT, charged per started hour."""
    return price_per_hour * math.ceil((end - start) / 60)

