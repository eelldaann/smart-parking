"""AI parking assistant.

The agent is an LLM with function calling. It does not touch the database
directly: it calls the same services as the REST API (search, forecast,
availability, booking, payment) as tools, and books only after the user confirms.

Without OPENAI_API_KEY it runs in an offline demo mode with a simple
rule-based parser, so the chat still works in class.
"""
import json
import re
import sqlite3
import urllib.error
import urllib.request
from datetime import timedelta

from .. import config
from . import ServiceError, bookings, lots, payments

MAX_STEPS = 6

TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "search_lots",
            "description": "Find parking lots. Returns price per hour, free spaces now and opening hours.",
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {"type": "string", "description": "Place, street or lot name, e.g. 'mall' or 'Abay'. Empty for all lots."},
                    "max_price": {"type": "integer", "description": "Maximum price per hour in KZT"},
                },
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "check_slot",
            "description": "Check bookable spaces, price and forecast occupancy for a lot and time slot.",
            "parameters": {
                "type": "object",
                "properties": {
                    "lot_id": {"type": "integer"},
                    "date": {"type": "string", "description": "YYYY-MM-DD"},
                    "start_time": {"type": "string", "description": "HH:MM"},
                    "end_time": {"type": "string", "description": "HH:MM"},
                },
                "required": ["lot_id", "date", "start_time", "end_time"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "book_and_pay",
            "description": "Create a reservation and a payment link. Call ONLY after the user has clearly confirmed the lot, date and time.",
            "parameters": {
                "type": "object",
                "properties": {
                    "lot_id": {"type": "integer"},
                    "date": {"type": "string", "description": "YYYY-MM-DD"},
                    "start_time": {"type": "string", "description": "HH:MM"},
                    "end_time": {"type": "string", "description": "HH:MM"},
                    "user_confirmed": {"type": "boolean", "description": "true only if the user explicitly confirmed this booking"},
                },
                "required": ["lot_id", "date", "start_time", "end_time", "user_confirmed"],
            },
        },
    },
]


def system_prompt() -> str:
    now = config.now()
    return (
        "You are the Smart Parking assistant for drivers in Almaty, Kazakhstan. "
        f"Today is {now:%A, %Y-%m-%d}, local time {now:%H:%M}. "
        "Help the driver find and book a parking space. Use the tools; never invent lots, prices or free spaces. "
        "Prices are in KZT per hour. When you suggest a slot, mention the price and the forecast occupancy. "
        "Before booking, repeat the lot, date, time and total price and ask the user to confirm. "
        "Only call book_and_pay after a clear 'yes'. After booking, tell the user to press the payment button. "
        "Answer briefly, in the same language the user writes in."
    )


class AgentSession:
    """Runs tools for one chat request and collects UI actions (lot cards, payment button)."""

    def __init__(self, conn: sqlite3.Connection, user_name: str):
        self.conn = conn
        self.user_name = user_name or "Guest"
        self.actions: list[dict] = []

    def run_tool(self, name: str, args: dict) -> dict:
        try:
            if name == "search_lots":
                found = lots.search(self.conn, args.get("query") or "", args.get("max_price"))
                if not found and args.get("query"):
                    found = lots.search(self.conn, "", args.get("max_price"))
                self.actions.append({"type": "lots", "lots": found[:4]})
                return {"lots": found[:6]}
            if name == "check_slot":
                slot = lots.availability(self.conn, args["lot_id"], args["date"], args["start_time"], args["end_time"])
                lot = lots.get_lot_row(self.conn, args["lot_id"])
                hour = lots.parse_time(args["start_time"]) // 60
                slot["forecast_occupancy"] = lots.occupancy(lot["kind"], lots.parse_date(args["date"]), hour)
                return slot
            if name == "book_and_pay":
                if not args.get("user_confirmed"):
                    return {"error": "Ask the user to confirm the booking first."}
                reservation = bookings.create(
                    self.conn, args["lot_id"], self.user_name, args["date"], args["start_time"], args["end_time"]
                )
                checkout = payments.start_checkout(self.conn, reservation["id"])
                self.actions.append({"type": "payment", "reservation": reservation, "payment_url": checkout["payment_url"]})
                return {"reservation_id": reservation["id"], "amount": reservation["amount"], "payment_ready": True}
            return {"error": f"Unknown tool {name}"}
        except ServiceError as err:
            return {"error": err.message}
        except (KeyError, TypeError) as err:
            return {"error": f"Missing or invalid argument: {err}"}


def _call_llm(messages: list[dict]) -> dict:
    base = config.env("OPENAI_BASE_URL", "https://api.openai.com/v1").rstrip("/")
    body = json.dumps({
        "model": config.env("OPENAI_MODEL", "gpt-4o-mini"),
        "messages": messages,
        "tools": TOOLS,
        "temperature": 0.2,
    }).encode()
    req = urllib.request.Request(f"{base}/chat/completions", data=body, method="POST")
    req.add_header("Authorization", f"Bearer {config.env('OPENAI_API_KEY')}")
    req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            return json.loads(resp.read())["choices"][0]["message"]
    except urllib.error.HTTPError as err:
        raise ServiceError(f"LLM error {err.code}: {err.read()[:300].decode(errors='ignore')}", 502)
    except urllib.error.URLError as err:
        raise ServiceError(f"Cannot reach the LLM API: {err.reason}", 502)


def chat(conn: sqlite3.Connection, history: list[dict], user_name: str, llm=_call_llm) -> dict:
    """history: [{"role": "user"|"assistant", "content": str}, ...]"""
    session = AgentSession(conn, user_name)
    clean = [
        {"role": m["role"], "content": str(m["content"])[:2000]}
        for m in history[-12:]
        if m.get("role") in ("user", "assistant") and m.get("content")
    ]
    if not clean or clean[-1]["role"] != "user":
        raise ServiceError("The last message must come from the user")

    if not config.env("OPENAI_API_KEY") and llm is _call_llm:
        return offline_reply(session, clean[-1]["content"])

    messages = [{"role": "system", "content": system_prompt()}, *clean]
    for _ in range(MAX_STEPS):
        message = llm(messages)
        calls = message.get("tool_calls") or []
        if not calls:
            return {"reply": message.get("content") or "", "actions": session.actions, "mode": "llm"}
        messages.append({"role": "assistant", "content": message.get("content"), "tool_calls": calls})
        for call in calls:
            try:
                args = json.loads(call["function"].get("arguments") or "{}")
            except json.JSONDecodeError:
                args = {}
            result = session.run_tool(call["function"]["name"], args)
            messages.append({"role": "tool", "tool_call_id": call["id"], "content": json.dumps(result, ensure_ascii=False)})
    return {"reply": "Sorry, I could not finish this request. Please try again.", "actions": session.actions, "mode": "llm"}


# ---------- offline demo mode (no API key) ----------

_TIME_RANGE = re.compile(r"(\d{1,2})[:.](\d{2})\s*[-–—до to]+\s*(\d{1,2})[:.](\d{2})")
_PRICE = re.compile(r"(\d{3,5})\s*(?:kzt|тг|тенге|₸)", re.IGNORECASE)
_STOP = {"find", "parking", "park", "near", "tomorrow", "today", "under", "найди", "парковку", "парковка",
         "возле", "около", "рядом", "завтра", "сегодня", "до", "for", "the", "with", "per", "hour", "час",
         "kzt", "тг", "тенге", "book", "забронируй", "please", "пожалуйста"}


def offline_reply(session: AgentSession, text: str) -> dict:
    lower = text.lower()
    price = _PRICE.search(lower)
    max_price = int(price.group(1)) if price else None
    words = [w for w in re.findall(r"[\w-]+", lower) if w not in _STOP and not w.isdigit() and len(w) > 2]
    found = session.run_tool("search_lots", {"query": " ".join(words), "max_price": max_price})["lots"]

    day = config.now().date() + timedelta(days=1 if ("tomorrow" in lower or "завтра" in lower) else 0)
    lines = []
    m = _TIME_RANGE.search(lower)
    if found and m:
        start, end = f"{int(m.group(1)):02d}:{m.group(2)}", f"{int(m.group(3)):02d}:{m.group(4)}"
        slot = session.run_tool("check_slot", {"lot_id": found[0]["id"], "date": day.isoformat(),
                                               "start_time": start, "end_time": end})
        if "error" not in slot:
            lines.append(
                f"{found[0]['name']}: {slot['bookable_spaces']} spaces bookable on {day:%d.%m} {start}–{end}, "
                f"{slot['price']} KZT, expected occupancy {round(slot['forecast_occupancy'] * 100)}%."
            )
    if found:
        lines.insert(0, f"I found {len(found)} lot(s)" + (f" up to {max_price} KZT/hour" if max_price else "") + ".")
        lines.append("Open a lot card to book it, or add an OpenAI key to let me book for you.")
    else:
        lines.append("I could not find a matching lot. Try another place or a higher price.")
    return {"reply": " ".join(lines) + " (offline demo mode)", "actions": session.actions, "mode": "offline"}
