"""Smart Parking REST API (FastAPI).

Run from the backend/ folder:  uvicorn app.main:app --reload
API docs: http://localhost:8000/docs
"""
from contextlib import asynccontextmanager

from fastapi import Depends, FastAPI, Header, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field

from . import config, db
from .services import ServiceError, agent, bookings, lots, owner_auth, payments


@asynccontextmanager
async def lifespan(_: FastAPI):
    db.init_db()
    yield


app = FastAPI(title="Smart Parking API", version="0.2.0", lifespan=lifespan)
app.add_middleware(
    CORSMiddleware,
    allow_origins=[config.frontend_url(), "http://localhost:5173", "http://127.0.0.1:5173"],
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.exception_handler(ServiceError)
async def service_error_handler(_: Request, err: ServiceError):
    return JSONResponse(status_code=err.status, content={"detail": err.message})


def get_conn():
    with db.connect() as conn:
        yield conn


# ---------- models ----------

class ReservationIn(BaseModel):
    lot_id: int
    user_name: str = Field(min_length=1, max_length=60)
    date: str
    start_time: str
    end_time: str


class ChatMessage(BaseModel):
    role: str
    content: str


class OwnerLoginIn(BaseModel):
    password: str


class ChatIn(BaseModel):
    messages: list[ChatMessage]
    user_name: str = "Guest"


# ---------- routes ----------

@app.get("/api/health")
def health():
    return {
        "status": "ok",
        "payment_provider": config.payment_provider_name(),
        "agent_mode": "llm" if config.env("OPENAI_API_KEY") else "offline",
    }


@app.get("/api/lots")
def list_lots(q: str = "", max_price: int | None = None, conn=Depends(get_conn)):
    return lots.search(conn, q, max_price)


@app.get("/api/lots/{lot_id}")
def get_lot(lot_id: int, conn=Depends(get_conn)):
    return lots.get_lot(conn, lot_id)


@app.get("/api/lots/{lot_id}/forecast")
def lot_forecast(lot_id: int, date: str, conn=Depends(get_conn)):
    return lots.forecast(conn, lot_id, date)


@app.get("/api/lots/{lot_id}/availability")
def lot_availability(lot_id: int, date: str, start_time: str, end_time: str, conn=Depends(get_conn)):
    return lots.availability(conn, lot_id, date, start_time, end_time)


@app.post("/api/reservations", status_code=201)
def create_reservation(body: ReservationIn, conn=Depends(get_conn)):
    return bookings.create(conn, body.lot_id, body.user_name, body.date, body.start_time, body.end_time)


@app.get("/api/reservations")
def my_reservations(user_name: str, conn=Depends(get_conn)):
    return bookings.list_for_user(conn, user_name)


@app.get("/api/reservations/{reservation_id}")
def get_reservation(reservation_id: int, conn=Depends(get_conn)):
    return bookings.get(conn, reservation_id)


@app.post("/api/reservations/{reservation_id}/cancel")
def cancel_reservation(reservation_id: int, conn=Depends(get_conn)):
    return bookings.cancel(conn, reservation_id)


@app.post("/api/reservations/{reservation_id}/pay")
def pay_reservation(reservation_id: int, conn=Depends(get_conn)):
    return payments.start_checkout(conn, reservation_id)


@app.get("/api/payments/confirm")
def confirm_payment(session_id: str, conn=Depends(get_conn)):
    return payments.confirm(conn, session_id)


@app.post("/api/payments/mock/{session_id}/complete")
def complete_mock_payment(session_id: str, conn=Depends(get_conn)):
    return payments.complete_mock(conn, session_id)


@app.post("/api/payments/webhook")
async def stripe_webhook(request: Request, conn=Depends(get_conn)):
    payload = await request.body()
    return payments.handle_webhook(conn, payload, request.headers.get("stripe-signature", ""))


@app.post("/api/agent/chat")
def agent_chat(body: ChatIn, conn=Depends(get_conn)):
    return agent.chat(conn, [m.model_dump() for m in body.messages], body.user_name)


def require_owner(authorization: str = Header(default="")):
    owner_auth.check(authorization)


@app.post("/api/owner/login")
def owner_login(body: OwnerLoginIn):
    return owner_auth.login(body.password)


@app.get("/api/owner/summary", dependencies=[Depends(require_owner)])
def owner_summary(conn=Depends(get_conn)):
    return bookings.owner_summary(conn)


@app.get("/api/owner/reservations", dependencies=[Depends(require_owner)])
def owner_reservations(conn=Depends(get_conn)):
    return bookings.list_all(conn)
