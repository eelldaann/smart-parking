"""Settings read from environment variables (and an optional .env file)."""
import os
from datetime import datetime
from zoneinfo import ZoneInfo

try:
    from dotenv import load_dotenv

    load_dotenv()
except ImportError:  # python-dotenv is optional
    pass

TIMEZONE = ZoneInfo("Asia/Almaty")


def env(name: str, default: str = "") -> str:
    return os.environ.get(name, default).strip()


def frontend_url() -> str:
    return env("FRONTEND_URL", "http://localhost:5173").rstrip("/")


def database_path() -> str:
    return env("DATABASE_PATH", "smart_parking.db")


def payment_provider_name() -> str:
    name = env("PAYMENT_PROVIDER").lower()
    if name in ("stripe", "mock"):
        return name
    return "stripe" if env("STRIPE_SECRET_KEY") else "mock"


def now() -> datetime:
    return datetime.now(TIMEZONE)
