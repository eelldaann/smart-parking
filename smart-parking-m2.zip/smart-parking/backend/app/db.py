"""SQLite storage: schema, sample data and a connection helper."""
import sqlite3
from contextlib import contextmanager

from . import config

SCHEMA = """
CREATE TABLE IF NOT EXISTS lots (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    address TEXT NOT NULL,
    lat REAL NOT NULL,
    lng REAL NOT NULL,
    kind TEXT NOT NULL,              -- mall | business | residential
    total_spaces INTEGER NOT NULL,
    online_spaces INTEGER NOT NULL,  -- spaces that can be booked online
    price_per_hour INTEGER NOT NULL, -- KZT
    opens TEXT NOT NULL,             -- HH:MM
    closes TEXT NOT NULL             -- HH:MM
);

CREATE TABLE IF NOT EXISTS reservations (
    id INTEGER PRIMARY KEY,
    lot_id INTEGER NOT NULL REFERENCES lots(id),
    user_name TEXT NOT NULL,
    date TEXT NOT NULL,              -- YYYY-MM-DD
    start_time TEXT NOT NULL,        -- HH:MM
    end_time TEXT NOT NULL,          -- HH:MM
    amount INTEGER NOT NULL,         -- KZT
    status TEXT NOT NULL,            -- pending | paid | cancelled
    payment_session TEXT,
    created_at TEXT NOT NULL
);
"""

# Sample lots in Almaty for the demo (invented names and figures).
SAMPLE_LOTS = [
    ("Central Mall Parking", "Abay Ave 44, Almaty", 43.2405, 76.9285, "mall", 80, 20, 400, "08:00", "23:00"),
    ("Riverside Mall Parking", "Rozybakiev St 247, Almaty", 43.2020, 76.8920, "mall", 120, 30, 300, "09:00", "23:00"),
    ("Arena Business Center", "Al-Farabi Ave 77, Almaty", 43.2185, 76.9270, "business", 60, 15, 500, "07:00", "21:00"),
    ("Old Square Parking", "Tole Bi St 55, Almaty", 43.2560, 76.9420, "business", 40, 10, 350, "07:00", "22:00"),
    ("Green Quarter Residence", "Timiryazev St 15, Almaty", 43.2290, 76.9030, "residential", 50, 12, 250, "00:00", "23:59"),
    ("Mountain View Plaza", "Dostyk Ave 210, Almaty", 43.2230, 76.9570, "mall", 70, 18, 450, "10:00", "22:00"),
]


@contextmanager
def connect(path: str | None = None):
    conn = sqlite3.connect(path or config.database_path(), check_same_thread=False)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db(path: str | None = None) -> None:
    with connect(path) as conn:
        conn.executescript(SCHEMA)
        count = conn.execute("SELECT COUNT(*) FROM lots").fetchone()[0]
        if count == 0:
            conn.executemany(
                "INSERT INTO lots (name, address, lat, lng, kind, total_spaces, online_spaces,"
                " price_per_hour, opens, closes) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                SAMPLE_LOTS,
            )
