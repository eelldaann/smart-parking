# Backend

FastAPI REST API (Python 3.10+) with SQLite. Sample parking lots in Almaty are created on first start.

## Run

```bash
cd backend
python3 -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env               # optional: add Stripe / OpenAI keys
uvicorn app.main:app --reload
```

API: http://localhost:8000 · interactive docs: http://localhost:8000/docs

Without any keys everything still works: payments use the **mock provider** (a fake checkout page) and the AI agent runs in **offline demo mode**.

## Modules

| File | What it does |
| --- | --- |
| `app/main.py` | REST endpoints |
| `app/services/lots.py` | lot search, occupancy forecast (baseline; ML model comes in Milestone 3), availability and price |
| `app/services/bookings.py` | reservations without double booking, owner summary |
| `app/services/payments.py` | payment providers: Stripe Checkout (test mode) and mock; webhook signature check |
| `app/services/agent.py` | AI assistant: LLM with function calling (search, check slot, book and pay) |

## Payments (Stripe test mode)

1. Create a Stripe account and switch to **Test mode**.
2. Put the secret test key (`sk_test_...`) into `.env` as `STRIPE_SECRET_KEY`.
3. Pay with the test card `4242 4242 4242 4242`, any future date, any CVC.
4. The booking is marked as paid when the user returns to the success page (`/api/payments/confirm`). For webhooks run `stripe listen --forward-to localhost:8000/api/payments/webhook` and put the `whsec_...` value into `STRIPE_WEBHOOK_SECRET`.

If Stripe is not available for the account, set `PAYMENT_PROVIDER=mock`.

## AI agent

Set `OPENAI_API_KEY` (and optionally `OPENAI_MODEL` / `OPENAI_BASE_URL` for any OpenAI-compatible provider). The agent has three tools: `search_lots`, `check_slot` and `book_and_pay`; it books only after the user confirms.

## Tests

```bash
pip install pytest
python -m pytest
```
