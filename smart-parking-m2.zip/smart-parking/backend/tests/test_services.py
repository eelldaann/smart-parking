import hashlib
import hmac
import json
import time
from datetime import timedelta

import pytest

from app import config, db
from app.services import ServiceError, agent, bookings, lots, payments


@pytest.fixture
def conn(tmp_path, monkeypatch):
    path = str(tmp_path / "test.db")
    monkeypatch.setenv("DATABASE_PATH", path)
    monkeypatch.setenv("PAYMENT_PROVIDER", "mock")
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    db.init_db(path)
    with db.connect(path) as c:
        yield c


def tomorrow() -> str:
    return (config.now().date() + timedelta(days=1)).isoformat()


def test_search_by_price_and_text(conn):
    cheap = lots.search(conn, "", 300)
    assert cheap and all(l["price_per_hour"] <= 300 for l in cheap)
    malls = lots.search(conn, "mall")
    assert malls and all("mall" in (l["name"] + l["kind"]).lower() for l in malls)


def test_forecast_covers_opening_hours(conn):
    f = lots.forecast(conn, 1, tomorrow())
    hours = [h["hour"] for h in f["hours"]]
    assert hours[0] == 8 and hours[-1] == 22
    assert all(0 <= h["occupancy"] <= 1 for h in f["hours"])


def test_price_is_per_started_hour(conn):
    slot = lots.availability(conn, 1, tomorrow(), "14:00", "15:30")
    assert slot["price"] == 800  # 400 KZT/hour, 2 started hours


def test_no_double_booking_beyond_online_spaces(conn):
    online = lots.get_lot(conn, 4)["online_spaces"]  # Old Square: 10 online spaces
    for i in range(online):
        bookings.create(conn, 4, f"user{i}", tomorrow(), "10:00", "12:00")
    with pytest.raises(ServiceError) as err:
        bookings.create(conn, 4, "late", tomorrow(), "11:00", "13:00")
    assert err.value.status == 409
    # a slot that does not overlap is still free
    assert bookings.create(conn, 4, "later", tomorrow(), "12:00", "13:00")["status"] == "pending"


def test_rejects_closed_hours_and_past(conn):
    with pytest.raises(ServiceError):
        bookings.create(conn, 1, "a", tomorrow(), "06:00", "09:00")  # opens 08:00
    yesterday = (config.now().date() - timedelta(days=1)).isoformat()
    with pytest.raises(ServiceError):
        bookings.create(conn, 1, "a", yesterday, "10:00", "11:00")


def test_mock_payment_flow(conn):
    r = bookings.create(conn, 1, "Eldana", tomorrow(), "14:00", "16:00")
    checkout = payments.start_checkout(conn, r["id"])
    assert checkout["provider"] == "mock" and "/mock-pay/" in checkout["payment_url"]
    assert payments.confirm(conn, checkout["session_id"])["status"] == "pending"
    paid = payments.complete_mock(conn, checkout["session_id"])
    assert paid["status"] == "paid"
    with pytest.raises(ServiceError):
        payments.start_checkout(conn, r["id"])  # already paid
    summary = {row["id"]: row for row in bookings.owner_summary(conn)}
    assert summary[1]["revenue"] == 800 and summary[1]["paid_count"] == 1


def test_stripe_webhook_signature_and_event(conn, monkeypatch):
    secret = "whsec_test"
    monkeypatch.setenv("STRIPE_WEBHOOK_SECRET", secret)
    r = bookings.create(conn, 2, "Eldana", tomorrow(), "10:00", "11:00")
    event = {"type": "checkout.session.completed",
             "data": {"object": {"metadata": {"reservation_id": str(r["id"])}, "payment_status": "paid"}}}
    payload = json.dumps(event).encode()
    t = int(time.time())
    sig = hmac.new(secret.encode(), f"{t}.".encode() + payload, hashlib.sha256).hexdigest()
    payments.handle_webhook(conn, payload, f"t={t},v1={sig}")
    assert bookings.get(conn, r["id"])["status"] == "paid"
    with pytest.raises(ServiceError):
        payments.handle_webhook(conn, payload, f"t={t},v1=deadbeef")


def test_agent_offline_mode_finds_lots(conn):
    out = agent.chat(conn, [{"role": "user", "content": "Find parking near Central Mall tomorrow 14:00–16:00 under 500 KZT"}], "Eldana")
    assert out["mode"] == "offline"
    names = [l["name"] for l in out["actions"][0]["lots"]]
    assert "Central Mall Parking" in names
    assert "800 KZT" in out["reply"]


def test_agent_uses_tools_and_books_only_after_confirmation(conn):
    day = tomorrow()
    script = iter([
        {"tool_calls": [{"id": "1", "function": {"name": "search_lots", "arguments": json.dumps({"query": "central"})}}]},
        {"tool_calls": [{"id": "2", "function": {"name": "book_and_pay", "arguments": json.dumps(
            {"lot_id": 1, "date": day, "start_time": "14:00", "end_time": "16:00", "user_confirmed": False})}}]},
        {"tool_calls": [{"id": "3", "function": {"name": "book_and_pay", "arguments": json.dumps(
            {"lot_id": 1, "date": day, "start_time": "14:00", "end_time": "16:00", "user_confirmed": True})}}]},
        {"content": "Booked! Press the payment button."},
    ])
    seen = []

    def fake_llm(messages):
        seen.append(messages[-1])
        return next(script)

    out = agent.chat(conn, [{"role": "user", "content": "Yes, book Central Mall 14-16 tomorrow"}], "Eldana", llm=fake_llm)
    assert out["reply"].startswith("Booked")
    assert "confirm" in seen[2]["content"]  # unconfirmed call was refused
    pay = [a for a in out["actions"] if a["type"] == "payment"][0]
    assert pay["reservation"]["amount"] == 800 and "/mock-pay/" in pay["payment_url"]


def test_owner_login_and_token(monkeypatch):
    from app.services import owner_auth
    monkeypatch.setenv("OWNER_PASSWORD", "secret")
    with pytest.raises(ServiceError) as err:
        owner_auth.login("wrong")
    assert err.value.status == 401
    token = owner_auth.login("secret")["token"]
    owner_auth.check(f"Bearer {token}")  # no error
    with pytest.raises(ServiceError):
        owner_auth.check("Bearer nope")
    with pytest.raises(ServiceError):
        owner_auth.check("")


def test_list_all_reservations(conn):
    bookings.create(conn, 1, "Ann", tomorrow(), "10:00", "11:00")
    bookings.create(conn, 2, "Bob", tomorrow(), "12:00", "13:00")
    rows = bookings.list_all(conn)
    assert [r["user_name"] for r in rows] == ["Bob", "Ann"]
    assert rows[0]["lot_name"] == "Riverside Mall Parking"
